
public class Game { //game�� �̸��� �޾� �����Ѵ�. 
	String gamename;
	String musicname;
	
	Game(String a, String b){
		gamename = a;
		musicname = b;
	}
	public String getGamename() {
		return gamename;
	}
	public void setGamename(String gamename) {
		this.gamename = gamename;
	}
	public String getMusicname() {
		return musicname;
	}
	public void setMusicname(String musicname) {
		this.musicname = musicname;
	}
	
}
