
public class Gcb {
	private String gameName;//���� �̸�. 
	private String gameMusic; // �ش� ���� �������� �� ����
	private String titleName; //�� ����
	
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public String getGameMusic() {
		return gameMusic;
	}
	public void setGameMusic(String gameMusic) {
		this.gameMusic = gameMusic;
	}
	public String getTitleName() {
		return titleName;
	}
	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}
	
	public Gcb(String gameName, String gameMusic, String titleName) {
		super();
		this.gameName = gameName;
		this.gameMusic = gameMusic;
		this.titleName = titleName;
	}

}
