import java.awt.Graphics2D;

public class JumpGame extends Thread { // ǥ�� ���߱� ����
	int gamelife = 3;
	JumpGame(String gametitle, String musictitle) {
		
	}
	public void doublebuffering(Graphics2D g){
		
	}
}