import javax.swing.SwingUtilities;

public class Main {
	public static final int SCREEN_WIDTH = 1280;
	public static final int SCREEN_HEIGHT = 720;
	public static int GAME_SPEED = 5;
	public static final int SLEEP_TIME = 10;
	public static int bestScore = -1; // �����ǿ� �����ִ� �ְ� ����.
	public static int GLife =5 ; //��� 5��.
	public static int CurPoint = 0 ;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SwingUtilities.invokeLater(new Runnable() {  
			 public void run() {
				 new GameSwitch();
			 }
		 });
	}

	public void InitSpeed() {
		GAME_SPEED = 5;
	}

	public void SpeedUp() {
		GAME_SPEED += 2;
	}

}
